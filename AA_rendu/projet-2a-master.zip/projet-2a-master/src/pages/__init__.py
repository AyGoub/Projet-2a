# Import des pages pour faciliter l'accès
from .connections_analyzer import *
from .activity_analyzer import *
from .preferences_analyzer import *
from .time_analyzer import *