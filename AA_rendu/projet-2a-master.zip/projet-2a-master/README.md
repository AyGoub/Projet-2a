# 📱 Instagram Data Analyzer

Une application Streamlit pour analyser vos données Instagram de manière interactive et détaillée.

## 🚀 Fonctionnalités

- **Analyse des Connexions** : Visualisez vos relations avec les autres utilisateurs
- **Analyse d'Activité** : Explorez vos interactions (likes, commentaires)
- **Analyse des Préférences** : Découvrez vos centres d'intérêt
- **Analyse Temporelle** : Comprenez vos habitudes d'utilisation
  - Heatmap d'activité par jour et heure
  - Durée des sessions
  - Distribution des thématiques
  - Métriques détaillées

## 🛠️ Installation

1. Clonez le repository :
```bash
git clone https://gitlab.ecole.ensicaen.fr/goubraim/projet-2a.git
cd Instagram-Insights
```

2. Installez les dépendances :
```bash
pip install -r requirements.txt
```

## 📦 Dépendances

- streamlit
- pandas
- plotly
- numpy
- python-dateutil

## 🎯 Utilisation

1. Lancez l'application :
```bash
streamlit run app.py
```

2. Téléchargez vos données Instagram :
   - Accédez à vos paramètres Instagram
   - Sélectionnez "Vos informations"
   - Choisissez "Télécharger vos informations"
   - Attendez l'email de confirmation
   - Décompressez le fichier ZIP reçu

3. Uploadez le fichier ZIP dans l'application

4. Explorez les différentes analyses dans les onglets :
   - Connections
   - Activité
   - Préférences
   - Temps & FOCUS

## 📊 Fonctionnalités par Onglet

### Connections
- Analyse des followers et following
- Statistiques de croissance
- Visualisations des relations

### Activité
- Analyse des likes et commentaires
- Tendances d'engagement
- Statistiques d'interaction

### Préférences
- Centres d'intérêt
- Thématiques favorites
- Évolution des préférences

### Temps & FOCUS
- Heatmap d'activité
- Durée des sessions
- Distribution temporelle
- Métriques détaillées

## 🔒 Sécurité

- Toutes les données sont traitées localement
- Aucune donnée n'est stockée de manière permanente
- Les fichiers temporaires sont supprimés après utilisation

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à :
1. Fork le projet
2. Créer une branche pour votre fonctionnalité
3. Commiter vos changements
4. Pousser vers la branche
5. Ouvrir une Pull Request


## 👥 Auteurs

- Saad Talemsi  
-Ayoub Goubraim
-Sylvain Génétiaux
-Anas Msanda

## 🙏 Remerciements

- Instagram pour l'accès aux données
- Streamlit pour le framework
- Plotly pour les visualisations 
- Nos encadrants pour leur suivi