import streamlit as st
import sys
import os
from src.utils.data_loader import TemporaryFileManager

# Ajouter le répertoire parent au chemin
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.pages.connections_analyzer import run_connections_analysis
from src.pages.activity_analyzer import run_activity_analysis
from src.pages.preferences_analyzer import run_preferences_analysis
from src.pages.time_analyzer import run_time_analysis
from constants.file_paths import CONNECTIONS_FILES, ACTIVITY_FILES, PREFERENCES_FILES

# Configuration principale
st.set_page_config(page_title='Instagram Data Analyzer', layout="wide")



# Section d'importation commune
st.title("Instagram Data Analyzer")

uploaded_file = st.file_uploader("Upload your Instagram data", type=['zip'])
# Section vidéo d'introduction
st.markdown("""
# 📱 Guide : Comment récupérer vos données Instagram

Cette vidéo vous montre comment télécharger vos données Instagram pour les analyser :
""")

# Vidéo d'introduction avec dimensions ajustées
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    st.video("constants/processus_recuperation_donnees.mp4")

st.markdown("""
### Étapes principales :
1. Accédez à vos paramètres Instagram
2. Sélectionnez "Vos informations"
3. Choisissez "Télécharger vos informations"
4. Attendez l'email de confirmation
5. Décompressez le fichier ZIP reçu
6. Uploadez-le ici pour l'analyse
""")

if uploaded_file is not None:
    # Stocker le fichier dans session_state pour accès global
    tfm = TemporaryFileManager()
    tfm.load_zip_to_temp(uploaded_file)
    st.session_state["tempFileManager"] = tfm
    
    # Charger les données Instagram
    instagram_data = {
        'connections': {},
        'activity': {},
        'preferences': {}
    }
    
    # Charger les fichiers de connexions
    for file_name in CONNECTIONS_FILES:
        if file_name in tfm.files_index:
            data = tfm.load_json(file_name)
            if data:
                instagram_data['connections'][file_name] = data
    
    # Charger les fichiers d'activité
    for file_name in ACTIVITY_FILES:
        if file_name in tfm.files_index:
            data = tfm.load_json(file_name)
            if data:
                instagram_data['activity'][file_name] = data
    
    # Charger les fichiers de préférences
    for file_name in PREFERENCES_FILES:
        if file_name in tfm.files_index:
            data = tfm.load_json(file_name)
            if data:
                instagram_data['preferences'][file_name] = data
    
    # Stocker les données dans session_state
    st.session_state.instagram_data = instagram_data
    st.success("Fichier chargé avec succès !")

# Interface principale avec onglets (ajout de l'onglet Time Analysis)
tab1, tab2, tab3, tab4 = st.tabs(["Connections", "Activité", "Préférences", "Temps & FOCUS"])


# Chaque onglet correspond à un module différent
with tab1:
    run_connections_analysis()

with tab2:
    run_activity_analysis()

with tab3:
    run_preferences_analysis()

with tab4:
    if 'tempFileManager' in st.session_state:
        run_time_analysis(file_manager=st.session_state.tempFileManager)
    elif 'instagram_data' in st.session_state:
        run_time_analysis(instagram_data=st.session_state.instagram_data)
    else:
        run_time_analysis()
       